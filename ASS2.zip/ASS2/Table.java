import java.util.*;
class Table{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        while(n!=11)
        {
            System.out.println(5+" * "+n+" = "+(5*n));
            n++;
        }
    }
}